<?php
if (extension_loaded('xdebug')) {
	include_once 'phptools_incl_commun.php' ;
	if (mustProfile($_SERVER['PHP_SELF'])){
		
		$needCookie=withCookie($_SERVER['PHP_SELF']) ;
		if ( ! $needCookie ){
			$tirage =  rand(1,RAND);
			if ($tirage === 1 ) {
				if(ini_get('xdebug.trace_enable_trigger') === '1'){
				
					setcookie('XDEBUG_TRACE','1');
					
				}
			
			 if (ini_get('xdebug.profiler_enable_trigger') === '1'){
				setcookie('XDEBUG_PROFILE','1');
				
				}
			register_shutdown_function('xdebug_footer');	
		}
		else
			{
			if (isset( $_COOKIE['XDEBUG_TRACE'])){
			setcookie('XDEBUG_TRACE',"",time()-3600);
				}
			if (isset( $_COOKIE['XDEBUG_PROFILE'])){
				setcookie('XDEBUG_PROFILE',"",time()-3600);
				}
			}
		}
	}
	
} 
function xdebug_footer(){
	
			if (isset( $_COOKIE['XDEBUG_TRACE'])){
			setcookie('XDEBUG_TRACE',"",time()-3600);
				}
			if (isset( $_COOKIE['XDEBUG_PROFILE'])){
				setcookie('XDEBUG_PROFILE',"",time()-3600);
				}
}
