<?php

if (extension_loaded('uprofiler')) {
	
	// see comments in included file phptools_incl_commun.php
	include_once 'phptools_incl_commun.php' ;
	
		
	if (mustProfile($_SERVER['PHP_SELF']))
		{
		$needCookie=withCookie($_SERVER['PHP_SELF']) ;
		if ( ! $needCookie || (($needCookie) && (isset($_COOKIE['UPROFILER_PROFILE'])))){
			// set the RAND variable in file phptools_incl_commun.php to the frequency of profiling that you want; 10 means : 1 profiled script each 10 runs. 
			
			$tirage =  rand(1,RAND);
			if ($tirage === 1 ) {
				if( SUIVIPROF === true )	{
					$t = microtime(true);
					$micro = sprintf("%06d",($t - floor($t)) * 1000000);
					$date = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );
					$date_format=$date->format ( "Y-m-d:H:i:s.u" );
					$nameFileSuivi=ini_get('uprofiler.output_dir')."/uprofiler.suivi.out";
					$treat=$date_format.";Begin treatment of ". $_SERVER['PHP_SELF'].";\n";
					file_put_contents($nameFileSuivi, $treat, FILE_APPEND | LOCK_EX );
				}
				register_shutdown_function('footer_mixed');
				uprofiler_enable(UPROFILER_FLAGS_CPU | UPROFILER_FLAGS_MEMORY);
				
			}
		}
	}
} 
function footer_mixed() {
	$uprofiler_data = uprofiler_disable();
	$datas=print_r($uprofiler_data, true);
	// Generation file for native uprofiler visualisation tools
	include_once $_SERVER['DOCUMENT_ROOT'] . "/phptools/uprofiler_lib/utils/uprofiler_lib.php";
	include_once $_SERVER['DOCUMENT_ROOT'] . "/phptools/uprofiler_lib/utils/uprofiler_runs.php";
	$uprofiler_runs = new uprofilerRuns_Default();
	$id=str_replace(":","_",str_replace(".","_",str_replace ("/" , "_" , $_SERVER['DOCUMENT_ROOT'] .$_SERVER['PHP_SELF'])));
	$run_id= $uprofiler_runs->save_run($uprofiler_data, $id);
	// Generation file for tool swingScaViewer
	$id=$id=str_replace(":","_",str_replace(".","_",str_replace ("/" , "_" , $_SERVER['DOCUMENT_ROOT'] .$_SERVER['PHP_SELF'])));
	$t = microtime(true);
	$micro = sprintf("%06d",($t - floor($t)) * 1000000);
	$date = new DateTime( date('Y-m-d H:i:s.'.$micro,$t) );
	$date_format=$date->format ( "Y-m-d:H:i:s.u" );
	$firstLine = "## NEW PROFILE FILE BEGIN\n";
	$lastLine="## NEW PROFILE FILE END=".$date_format."\n";
	if( SUIVIPROF === true )	{
		$nameFileSuivi=ini_get('uprofiler.output_dir')."/uprofiler_suivi.out";
		$treat=$date_format.";End treatment of". $_SERVER['PHP_SELF'].";\n";
		file_put_contents($nameFileSuivi, $treat, FILE_APPEND | LOCK_EX );
	}
	$toWrite=$firstLine."cmd=".$_SERVER['DOCUMENT_ROOT'].$_SERVER['PHP_SELF']."\n".$datas."\n".$lastLine."\n";
	$nameFile=ini_get('uprofiler.output_dir')."/uprofiler_".$id.".out";
	file_put_contents($nameFile, $toWrite, FILE_APPEND | LOCK_EX );
	if (isset( $_COOKIE["UPROFILER_PROFILE"]) ) {
		setcookie("UPROFILER_PROFILE", "", time()-3600);
	}
}

