<?php
// set array of pattern of wanted scripts to profile
	// can take 2 forms for value :
	//  - withCookie => only for HPROF it is profiled if a cookie XHPROF_PROFILE is present and $tirage === 1 
	//	- noCookie => always profiled if $tirage === 1 


define ('PATTERNS',serialize(  array(
'/phpmyadmin/index.php' => 'noCookie',
		'testjlp' => 'noCookie',
		'memory' => 'noCookie',
		'filRougeJ1-J2' => 'noCookie'
//,'white' => 'noCookie'
//	,'version_check.php' => 'noCookie'
	)));

// Some file containing AJAX or JS scripts may not run correctly with xhprof, you can exclude them:
// key is just a mnemonic, the value is the pattern to exclude here
define ("EXCLUDED" , serialize (array ('javascript' => 'js')));
//define ("EXCLUDED" , serialize (array ('testExcl' => '/phpmyadmin/index.php' )));
//define ("EXCLUDED" , serialize (array ('include'=>'/phpmyadmin/index.php')));
// Sampling one script every rand.
// rand = 10 means profile 1 script every 10 runs of the script.
// to  always profile a script set RAND to "1"
define ('RAND' , '1');

// to follow the execution of xhprof/uprofiler
// gives a little level of  debug
define ('SUIVIPROF', false);


// Don't cross the line below !
//================================================================================================

if (extension_loaded('xhprof') || extension_loaded('uprofiler') || extension_loaded('xdebug') ) {
	if(!function_exists("mustProfile")) {
		function mustProfile($script) {
		$myReturn=false;
			$patterns= unserialize (PATTERNS);
			$excluded = unserialize (EXCLUDED);
			foreach($patterns as $key => $value){
		
				if (strpos($script,$key ) !== false){
					$myReturn=true;
					foreach($excluded as $key2 => $value2){
		
						if (strpos($script,$value2 ) !== false)
						{
							
							$myReturn=false ;
						}
					}

				}
				
			}
			return $myReturn;;
	
		}

// This function is useful when using stress tools like JMeter/LoadRunner/... to trigger a profiling with a cookie when set by the tool.
		function withCookie($script) {
			$patterns= unserialize (PATTERNS);
			$myReturn=false;
			foreach($patterns as $key => $value){
		
				if (strpos($script,$key ) !== false)
				{
					if ($value === 'withCookie') {
	
					$myReturn= true;
					}
					else {
						$myReturn=false ;
					}
				}
			}
		return $myReturn;
		}
		
		// These 2 functions are useful when using stress tool and adding dynamically the param XDEBUG_TRACE or XDEBUG_PROFILE
		function url_origin($s, $use_forwarded_host=false){
			$ssl = (!empty($s['HTTPS']) && $s['HTTPS'] == 'on') ? true:false;
			$sp = strtolower($s['SERVER_PROTOCOL']);
			$protocol = substr($sp, 0, strpos($sp, '/')) . (($ssl) ? 's' : '');
			$port = $s['SERVER_PORT'];
			$port = ((!$ssl && $port=='80') || ($ssl && $port=='443')) ? '' : ':'.$port;
			$host = ($use_forwarded_host && isset($s['HTTP_X_FORWARDED_HOST'])) ? $s['HTTP_X_FORWARDED_HOST'] : (isset($s['HTTP_HOST']) ? $s['HTTP_HOST'] : null);
			$host = isset($host) ? $host : $s['SERVER_NAME'] . $port;
		return $protocol . '://' . $host;
		}
		function full_url($s, $use_forwarded_host=false){
		return url_origin($s, $use_forwarded_host) . $s['REQUEST_URI'];
		}
		
		function remove_from_query_string( $needle) {
				$query_string = $_SERVER['QUERY_STRING']; // Work on a seperate copy and preserve the original for now
				// echo "<br/> avant traitement ".$query_string ;
				// echo "<br/> avant traitement URI ".$_SERVER['REQUEST_URI'];
				//$query_string = preg_replace("/\&$needle=[a-zA-Z0-9].*?(\&|$)/", '&', $query_string);
				$query_string = preg_replace("/\&?$needle(=[a-zA-Z0-9])?.*?(\&|$)/", '&', $query_string);
				$query_string = preg_replace("/\&+/","&",$query_string);				 // Supposed to pull out all repeating &s, however it allows 2 in a row(&&). Good enough for now
				$query_string = preg_replace("/^\&+/","",$query_string);	 // kiil the first & if it is the first character
				$_SERVER['QUERY_STRING'] = $query_string;
				$uri=$_SERVER['REQUEST_URI'];
				$uri=preg_replace("/\?.*$/","",$uri);	
				$_SERVER['REQUEST_URI']=$uri ;
				// echo "<br/> apres traitement ".$query_string ;
				// echo "<br/> apres traitement URI ".$_SERVER['REQUEST_URI'];
			}
	}
} 

