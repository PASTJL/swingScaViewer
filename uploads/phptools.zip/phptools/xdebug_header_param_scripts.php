<?php
if (extension_loaded('xdebug')) {
	include_once 'phptools_incl_commun.php' ;
	$query_array= array();
	 parse_str($_SERVER['QUERY_STRING'], $query_array);
	$query=$_SERVER['QUERY_STRING'];
	if (mustProfile($_SERVER['PHP_SELF']) )
		{
			
		$tirage =  rand(1,RAND);
		if ($tirage === 1 ) {
			if(ini_get('xdebug.trace_enable_trigger') === '1'){
			if (!isset($query_array['XDEBUG_TRACE'])){
				
				$absolute_url = full_url($_SERVER);
				if (empty($query_array))
					{
					$absolute_url .= "?XDEBUG_TRACE=1";
					}
				else
					{
					$absolute_url .= $query."&XDEBUG_TRACE=1";
					}
				header('Location: '.$absolute_url) ;
				exit;
				 } 
			 }
			if(ini_get('xdebug.profiler_enable_trigger') === '1'){
				if (!isset($query_array['XDEBUG_PROFILE'])){
				$absolute_url = full_url($_SERVER);
				if (empty($query_array))
					{
					$absolute_url .= "?XDEBUG_PROFILE=1";
					}
				else
					{
					$absolute_url .= $query."&XDEBUG_PROFILE=1";
					}
				header('Location: '.$absolute_url) ;
				exit;
				 } 
				
				
				
			} 
		 }
	}
			if ( isset($query_array['XDEBUG_TRACE'])){
				remove_from_query_string('XDEBUG_TRACE');
				}
				
				if ( isset($query_array['XDEBUG_PROFILE'])){
				remove_from_query_string('XDEBUG_PROFILE');
				}
				
}
