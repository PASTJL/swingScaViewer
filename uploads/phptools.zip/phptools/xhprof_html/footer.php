<?php
if (extension_loaded('xhprof')) { 
  $profileName = 'profil'; 
  // nom de l'application
  $xhprof_data = xhprof_disable();
  $xhprof_runs = new XHProfRuns_Default(); 
  // Classe issue de /xhprof_lib
  $run_id = $xhprof_runs->save_run($xhprof_data, $profileName);
  // url vers les bibliothèques graphiques, /xhprof_html 
   $profiler_url =sprintf('http://localhost/xhprof/xhprof_html/index.php?run=%s&source=%s',$run_id, $profileName);
       printf('<br><br>&nbsp;&nbsp;&nbsp;<a href="%s"target="_blank">Profiler output</a><br>', $profiler_url);

  }
?>